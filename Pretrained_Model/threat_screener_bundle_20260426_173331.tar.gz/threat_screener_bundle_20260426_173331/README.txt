Threat Screener Model Bundle
============================

Created: 2026-04-26 21:33:47 UTC
Bundle:  threat_screener_bundle_20260426_173331
Winner:  C
XGBoost: 3.2.0

QUICK START
-----------

# 1. Extract the bundle
tar -xzf threat_screener_bundle_20260426_173331.tar.gz
cd threat_screener_bundle_20260426_173331/

# 2. Install dependencies (numpy + xgboost)
pip install numpy xgboost

# 3. Score a FASTA file
python loader.py . < my_sequences.fasta > results.csv
#      ^
#      bundle directory (contains model.json, etc.)

# Or use as a library
python3 -c "
from loader import ThreatScreenBundle
b = ThreatScreenBundle.load('.')
r = b.classify('ATGCGATCGATCGATCGATCGATCGATCGATCGATCGAT', fpr_target=0.05)
print(r)
"

CONTENTS
--------

model.json                    XGBoost booster (native JSON format)
dna_scores.json               DNA k-mer log-odds scores
prot_scores.json              Protein k-mer log-odds scores
dna_km2i.json                 DNA k-mer -> feature index map
pkm2i.json                    Protein k-mer -> feature index map
threat_longkmers.txt.gz       Reverse-screening threat k-mer set
innocuous_longkmers.txt.gz    Reverse-screening innocuous k-mer set
thresholds.json               Per-length-bucket calibrated thresholds
metadata.json                 Config, provenance, known limitations
loader.py                     Standalone Python loader + CLI
README.txt                    This file

KNOWN LIMITATIONS
-----------------

See metadata.json 'known_limitations' field for a detailed list. Briefly:

* The model has a compositional bias toward AT-rich sequences (they score
  too high). Review any flagged sequence with GC<0.35 manually.
* Scoring is near-random below 15bp query length.
* This is a statistical prescreen, not an exact-match biosecurity tool.
  Pair with homology search (BLAST/HMMER) or expert review for operational
  decisions.
