"""
threat_screen loader -- standalone reference implementation.

Usage as a library:
    from loader import ThreatScreenBundle
    bundle = ThreatScreenBundle.load('path/to/bundle/directory')
    score = bundle.score('ATGCGATCGATCGAT...')
    result = bundle.classify('ATGCGATCGATCGAT...', fpr_target=0.05)

Usage as a CLI (reads FASTA from stdin, writes CSV to stdout):
    python loader.py bundle_dir < input.fasta > results.csv

Requirements: xgboost, numpy
"""
import json, gzip, math, sys, os
from pathlib import Path

import numpy as np
import xgboost as xgb

# ----- codon table for 6-frame translation -----
_CODON = {
    'TTT':'F','TTC':'F','TTA':'L','TTG':'L','TCT':'S','TCC':'S','TCA':'S','TCG':'S',
    'TAT':'Y','TAC':'Y','TAA':'*','TAG':'*','TGT':'C','TGC':'C','TGA':'*','TGG':'W',
    'CTT':'L','CTC':'L','CTA':'L','CTG':'L','CCT':'P','CCC':'P','CCA':'P','CCG':'P',
    'CAT':'H','CAC':'H','CAA':'Q','CAG':'Q','CGT':'R','CGC':'R','CGA':'R','CGG':'R',
    'ATT':'I','ATC':'I','ATA':'I','ATG':'M','ACT':'T','ACC':'T','ACA':'T','ACG':'T',
    'AAT':'N','AAC':'N','AAA':'K','AAG':'K','AGT':'S','AGC':'S','AGA':'R','AGG':'R',
    'GTT':'V','GTC':'V','GTA':'V','GTG':'V','GCT':'A','GCC':'A','GCA':'A','GCG':'A',
    'GAT':'D','GAC':'D','GAA':'E','GAG':'E','GGT':'G','GGC':'G','GGA':'G','GGG':'G',
}
_COMP = str.maketrans('ACGT', 'TGCA')
def _revcomp(s): return s.translate(_COMP)[::-1]
def _translate(s):
    return ''.join(_CODON.get(s[i:i+3], 'X') for i in range(0, len(s) - 2, 3))

# ----- optional DUST masking (matches training-time preprocessing) -----
def _triplet_entropy(window):
    if len(window) < 3: return 0.0
    from collections import Counter
    c = Counter(window[i:i+3] for i in range(len(window)-2))
    total = sum(c.values())
    if total == 0: return 0.0
    h = 0.0
    for v in c.values():
        p = v / total
        if p > 0: h -= p * math.log2(p)
    return h

def dust_mask(seq, window=32, threshold=2.5):
    if len(seq) < window:
        return 'N' * len(seq) if _triplet_entropy(seq) < threshold else seq
    masked = list(seq)
    any_masked = False
    for i in range(len(seq) - window + 1):
        if _triplet_entropy(seq[i:i+window]) < threshold:
            for j in range(i, i + window):
                masked[j] = 'N'
            any_masked = True
    return ''.join(masked) if any_masked else seq

class ThreatScreenBundle:
    """Loader for a threat screening model bundle produced by the
    SeqScreen notebook's PATCH H v8 export cell."""

    def __init__(self, model, dna_scores, prot_scores, dna_km2i, pkm2i,
                 t_long, i_long, thresholds, metadata):
        self.model = model
        self.dna_scores = dna_scores
        self.prot_scores = prot_scores
        self.dna_km2i = dna_km2i
        self.pkm2i = pkm2i
        self.t_long = t_long
        self.i_long = i_long
        self.thresholds = thresholds
        self.metadata = metadata
        self._n_dna = len(dna_km2i)
        self._n_prot = len(pkm2i)
        self._k_dna = metadata['k_dna']
        self._k_prot = metadata['k_prot']
        self._k_long = metadata['k_long']
        self._applies_dust = metadata['applies_dust_masking']
        self._rev_screen = metadata['rev_screen_enabled']

    @classmethod
    def load(cls, bundle_dir):
        """Load a bundle from an extracted directory."""
        d = Path(bundle_dir)
        if not d.is_dir():
            raise FileNotFoundError(f"bundle directory not found: {d}")

        with open(d / 'metadata.json') as f:
            metadata = json.load(f)

        model = xgb.Booster()
        model.load_model(str(d / 'model.json'))

        with open(d / 'dna_scores.json') as f:
            dna_scores = json.load(f)
        with open(d / 'prot_scores.json') as f:
            prot_scores = json.load(f)
        with open(d / 'dna_km2i.json') as f:
            dna_km2i = json.load(f)
        with open(d / 'pkm2i.json') as f:
            pkm2i = json.load(f)

        t_long = i_long = None
        tl_path = d / 'threat_longkmers.txt.gz'
        il_path = d / 'innocuous_longkmers.txt.gz'
        if tl_path.exists():
            with gzip.open(tl_path, 'rt') as f:
                t_long = set(line.strip() for line in f if line.strip())
        if il_path.exists():
            with gzip.open(il_path, 'rt') as f:
                i_long = set(line.strip() for line in f if line.strip())

        with open(d / 'thresholds.json') as f:
            thresholds = json.load(f)

        print(f"[ThreatScreenBundle] loaded from {d}")
        print(f"  winner_condition: {metadata['winner_condition']}")
        print(f"  {len(dna_km2i)} DNA k-mers, {len(pkm2i)} protein k-mers")
        if t_long: print(f"  {len(t_long)} threat long-k-mers, "
                         f"{len(i_long) if i_long else 0} innocuous long-k-mers")
        print(f"  applies_dust_masking: {metadata['applies_dust_masking']}")
        print(f"  rev_screen_enabled: {metadata['rev_screen_enabled']}")

        return cls(model, dna_scores, prot_scores, dna_km2i, pkm2i,
                   t_long, i_long, thresholds, metadata)

    def _feat_vec(self, seq):
        """Produce the concatenated [DNA-presence | protein-presence] feature vector."""
        if self._applies_dust:
            seq = dust_mask(seq)
        vd = np.zeros(self._n_dna, dtype=np.float32)
        vp = np.zeros(self._n_prot, dtype=np.float32)
        k = self._k_dna
        if len(seq) >= k:
            for i in range(len(seq) - k + 1):
                km = seq[i:i+k]
                if 'N' in km: continue
                idx = self.dna_km2i.get(km)
                if idx is not None: vd[idx] += 1
            vd = vd / max(1, len(seq) - k + 1)
        # 6-frame protein
        kp = self._k_prot
        for fs in (seq[0:], seq[1:], seq[2:]):
            p = _translate(fs)
            for i in range(len(p) - kp + 1):
                pk = p[i:i+kp]
                if 'X' in pk or '*' in pk: continue
                idx = self.pkm2i.get(pk)
                if idx is not None: vp[idx] += 1
        rc = _revcomp(seq)
        for fs in (rc[0:], rc[1:], rc[2:]):
            p = _translate(fs)
            for i in range(len(p) - kp + 1):
                pk = p[i:i+kp]
                if 'X' in pk or '*' in pk: continue
                idx = self.pkm2i.get(pk)
                if idx is not None: vp[idx] += 1
        return np.concatenate([vd, vp])

    def _reverse_screen(self, seq, base_prob):
        if not self._rev_screen or self.t_long is None:
            return base_prob
        if len(seq) < self._k_long:
            return base_prob
        th = 0; ih = 0
        for i in range(len(seq) - self._k_long + 1):
            km = seq[i:i+self._k_long]
            if km in self.t_long: th += 1
            if km in self.i_long: ih += 1
        if th + ih == 0:
            return base_prob
        return math.sqrt(float(base_prob) * max(0.001, th / (th + ih)))

    def score(self, seq):
        """Return probability in [0, 1] that seq is a threat."""
        seq = seq.upper()
        X = np.array([self._feat_vec(seq)], dtype=np.float32)
        p_raw = float(self.model.predict(xgb.DMatrix(X))[0])
        return self._reverse_screen(seq, p_raw)

    def score_batch(self, seqs):
        """Vectorized scoring. Returns numpy array of probabilities."""
        seqs = [s.upper() for s in seqs]
        X = np.array([self._feat_vec(s) for s in seqs], dtype=np.float32)
        raw = self.model.predict(xgb.DMatrix(X))
        out = np.empty_like(raw)
        for i, s in enumerate(seqs):
            out[i] = self._reverse_screen(s, raw[i])
        return out

    def classify(self, seq, fpr_target=0.05):
        """Return a dict: {score, threshold, bucket, call, length, warning}."""
        seq = seq.upper()
        p = self.score(seq)
        L = len(seq)

        # Find applicable threshold bucket
        chosen = None; chosen_bucket = None
        for bucket in self.thresholds['buckets']:
            if bucket['lo'] <= L < bucket['hi'] and bucket['thresholds']:
                chosen = bucket['thresholds'].get(str(fpr_target))
                if chosen is None:
                    # Try near matches (JSON serializes 0.05 as "0.05" but be defensive)
                    for k, v in bucket['thresholds'].items():
                        if abs(float(k) - fpr_target) < 1e-6:
                            chosen = v; break
                chosen_bucket = [bucket['lo'], bucket['hi']]
                break

        call = 'threat' if (chosen is not None and p >= chosen) else 'benign'

        # GC-bias warning (per metadata)
        g = seq.count('G') + seq.count('C')
        n_informative = max(1, len(seq) - seq.count('N'))
        gc = g / n_informative
        warning = None
        if gc < 0.35 and call == 'threat':
            warning = ("Low GC content (gc={:.2f}). This model is known to over-flag "
                       "AT-rich benign sequences; recommend manual review.".format(gc))
        elif L < 15:
            warning = "Sequence below 15bp; scoring is near-random below this length."
        elif chosen is None:
            warning = (f"No calibrated threshold for length bucket covering {L}bp; "
                       "call is based on a default threshold -- operating point may drift.")

        return {
            'score': float(p),
            'threshold': float(chosen) if chosen is not None else None,
            'bucket': chosen_bucket,
            'fpr_target': fpr_target,
            'call': call,
            'length': L,
            'gc_content': round(gc, 3),
            'warning': warning,
        }

# ---- reference CLI: read FASTA from stdin, write CSV to stdout ----
def _cli():
    import argparse, csv
    parser = argparse.ArgumentParser(
        description="Score DNA sequences from a FASTA file using a threat screener bundle.")
    parser.add_argument('bundle_dir',
                        help="Path to the extracted bundle directory (contains model.json etc.)")
    parser.add_argument('--fpr', type=float, default=0.05,
                        help="Target false-positive rate for classify threshold (default 0.05)")
    parser.add_argument('--input', default='-',
                        help="Input FASTA file ('-' for stdin, default)")
    parser.add_argument('--output', default='-',
                        help="Output CSV file ('-' for stdout, default)")
    args = parser.parse_args()

    bundle = ThreatScreenBundle.load(args.bundle_dir)

    # Read FASTA
    def _read_fasta(fh):
        name = None; seq_parts = []
        for line in fh:
            line = line.rstrip('\n').rstrip('\r')
            if line.startswith('>'):
                if name is not None:
                    yield name, ''.join(seq_parts)
                name = line[1:].split()[0] if len(line) > 1 else 'unnamed'
                seq_parts = []
            else:
                seq_parts.append(line.strip().upper())
        if name is not None:
            yield name, ''.join(seq_parts)

    in_f = sys.stdin if args.input == '-' else open(args.input)
    out_f = sys.stdout if args.output == '-' else open(args.output, 'w', newline='')
    writer = csv.writer(out_f)
    writer.writerow(['name', 'length', 'gc_content', 'score', 'threshold', 'call', 'warning'])

    n = 0
    for name, seq in _read_fasta(in_f):
        if not seq: continue
        r = bundle.classify(seq, fpr_target=args.fpr)
        writer.writerow([name, r['length'], r['gc_content'],
                         f"{r['score']:.4f}",
                         f"{r['threshold']:.4f}" if r['threshold'] is not None else '',
                         r['call'], r['warning'] or ''])
        n += 1

    if args.input != '-': in_f.close()
    if args.output != '-': out_f.close()
    print(f"[loader] scored {n} sequences", file=sys.stderr)

if __name__ == '__main__':
    _cli()
